#!/bin/sh
curl https://raw.github.com/boxeehacks/boxeehack/master/install/install.sh -o /download/install.sh
sh /download/install.sh &
