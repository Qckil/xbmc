#!/bin/sh
mount -o bind /data/hack/boxee_screen_saver /opt/boxee/media/boxee_screen_saver
