#!/bin/sh
sh /data/hack/skin.sh &
sh /data/hack/screensaver.sh &
sh /data/hack/visualiser.sh &
sh /data/hack/subtitles.sh &
sh /data/hack/logo.sh &
sh /data/hack/apps.sh &
sh /data/hack/network.sh &
sh /data/hack/telnet.sh &
sh /data/hack/ftp.sh &
