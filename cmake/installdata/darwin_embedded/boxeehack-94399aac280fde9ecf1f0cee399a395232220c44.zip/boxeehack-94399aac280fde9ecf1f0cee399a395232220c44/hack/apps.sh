#!/bin/sh
cp -R /data/hack/apps/browser2 /data/.boxee/UserData/apps/
