#!/bin/sh
dtool 6 1 0 0
dtool 6 2 0 50
