#!/bin/sh
mount -o bind /data/hack/boxee/skin/boxee/720p /opt/boxee/skin/boxee/720p
