#!/bin/sh
/data/hack/bin/busybox telnetd -p 2323 -l /data/hack/shell.sh &
