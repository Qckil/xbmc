#!/bin/sh
mount -o bind /data/hack/projectm /opt/boxee/visualisations/projectM
